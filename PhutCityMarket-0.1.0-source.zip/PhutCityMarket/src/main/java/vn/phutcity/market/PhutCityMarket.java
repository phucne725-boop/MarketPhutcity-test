package vn.phutcity.market;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Directional;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay.ItemDisplayTransform;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;
import org.bukkit.Location;
import org.bukkit.util.Vector;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class PhutCityMarket extends JavaPlugin implements Listener {
    private final Map<String, ShelfData> openEditors = new HashMap<>();
    private final Map<UUID, PendingPrice> pendingPriceSlot = new HashMap<>();
    private File shelvesFile;
    private YamlConfiguration shelves;
    private NamespacedKey displayMarkerKey;
    private NamespacedKey displayShelfKey;

    private static final int[] PRODUCT_SLOTS = {10, 13, 16};
    private static final int SAVE_SLOT = 22;
    private static final int CLOSE_SLOT = 26;
    private static final String TITLE = ChatColor.DARK_BLUE + "PHUT CITY | QUAN LY KE HANG";

    @Override
    public void onEnable() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().severe("Cannot create plugin data folder.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        shelvesFile = new File(getDataFolder(), "shelves.yml");
        loadShelves();
        displayMarkerKey = new NamespacedKey(this, "market_shelf_display");
        displayShelfKey = new NamespacedKey(this, "market_shelf_key");
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("PhutCityMarket enabled. Shelf admin GUI ready.");
    }

    private void loadShelves() {
        shelves = YamlConfiguration.loadConfiguration(shelvesFile);
    }

    private void saveShelves() {
        try {
            shelves.save(shelvesFile);
        } catch (IOException ex) {
            getLogger().severe("Could not save shelves.yml: " + ex.getMessage());
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used in-game.");
            return true;
        }
        if (!isAdmin(player)) {
            player.sendMessage(ChatColor.RED + "Ban khong co quyen su dung.");
            return true;
        }
        Block target = player.getTargetBlockExact(6);
        if (target == null || !isShelf(target.getType())) {
            player.sendMessage(ChatColor.YELLOW + "Hay nhin vao block Shelf trong tam 6 block roi dung /marketadmin.");
            return true;
        }
        openEditor(player, target);
        return true;
    }

    @EventHandler(ignoreCancelled = true)
    public void onShelfClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;
        Block block = event.getClickedBlock();
        if (!isShelf(block.getType())) return;
        Player player = event.getPlayer();
        if (!isAdmin(player)) {
            // Prevent direct vanilla shelf manipulation: shelf contents are managed by the shop plugin.
            event.setCancelled(true);
            player.sendMessage(ChatColor.GRAY + "Ke hang duoc quan ly boi he thong sieu thi.");
            return;
        }
        event.setCancelled(true);
        openEditor(player, block);
    }

    private boolean isShelf(Material material) {
        return material.name().endsWith("_SHELF");
    }

    private boolean isAdmin(Player player) {
        return player.isOp() || player.hasPermission("phutcity.market.admin");
    }

    private String key(Block block) {
        return block.getWorld().getName() + "," + block.getX() + "," + block.getY() + "," + block.getZ();
    }

    private ShelfData readShelf(String key) {
        ShelfData data = new ShelfData(key);
        String base = "shelves." + key;
        for (int i = 0; i < 3; i++) {
            String path = base + ".slot" + i;
            if (shelves.contains(path + ".item")) {
                data.items[i] = shelves.getItemStack(path + ".item");
                data.prices[i] = shelves.getDouble(path + ".price", 0.0);
            }
        }
        return data;
    }

    private void writeShelf(ShelfData data) {
        String base = "shelves." + data.key;
        for (int i = 0; i < 3; i++) {
            String path = base + ".slot" + i;
            if (data.items[i] == null || data.items[i].getType().isAir()) {
                shelves.set(path, null);
            } else {
                shelves.set(path + ".item", data.items[i]);
                shelves.set(path + ".price", data.prices[i]);
            }
        }
        saveShelves();
        refreshDisplays(data);
    }

    private void refreshDisplays(ShelfData data) {
        String[] parts = data.key.split(",", 4);
        if (parts.length != 4) return;
        org.bukkit.World world = Bukkit.getWorld(parts[0]);
        if (world == null) return;
        int x, y, z;
        try { x = Integer.parseInt(parts[1]); y = Integer.parseInt(parts[2]); z = Integer.parseInt(parts[3]); }
        catch (NumberFormatException ex) { return; }
        Block block = world.getBlockAt(x, y, z);
        if (!isShelf(block.getType())) return;
        for (Entity entity : world.getNearbyEntities(block.getLocation().add(0.5, 0.5, 0.5), 1.5, 1.5, 1.5)) {
            if (entity.getPersistentDataContainer().has(displayMarkerKey, PersistentDataType.BYTE)
                    && data.key.equals(entity.getPersistentDataContainer().get(displayShelfKey, PersistentDataType.STRING))) entity.remove();
        }
        BlockFace facing = block.getBlockData() instanceof Directional directional ? directional.getFacing() : BlockFace.NORTH;
        Vector front = new Vector(facing.getModX(), 0, facing.getModZ());
        Vector side = new Vector(-front.getZ(), 0, front.getX());
        for (int i = 0; i < 3; i++) {
            ItemStack item = data.items[i];
            if (item == null || item.getType().isAir()) continue;
            double offset = (i - 1) * 0.28;
            Location location = block.getLocation().add(0.5, 0.38, 0.5).add(front.clone().multiply(0.53)).add(side.clone().multiply(offset));
            ItemDisplay display = world.spawn(location, ItemDisplay.class, d -> {
                d.setItemStack(item.clone());
                d.setItemDisplayTransform(ItemDisplayTransform.FIXED);
                d.setPersistent(true);
                d.getPersistentDataContainer().set(displayMarkerKey, PersistentDataType.BYTE, (byte) 1);
                d.getPersistentDataContainer().set(displayShelfKey, PersistentDataType.STRING, data.key);
                d.setInvulnerable(true);
                d.setGravity(false);
            });
        }
    }

    private void openEditor(Player player, Block block) {
        String key = key(block);
        ShelfData data = readShelf(key);
        ShelfHolder holder = new ShelfHolder(key);
        Inventory inv = Bukkit.createInventory(holder, 27, TITLE);
        holder.inventory = inv;
        render(inv, data);
        openEditors.put(player.getUniqueId().toString(), data);
        player.openInventory(inv);
        player.sendMessage(ChatColor.GREEN + "Dang quan ly ke hang: " + key);
    }

    private void render(Inventory inv, ShelfData data) {
        ItemStack pane = named(Material.GRAY_STAINED_GLASS_PANE, ChatColor.DARK_GRAY + " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
        for (int i = 0; i < 3; i++) {
            ItemStack item = data.items[i] == null ? named(Material.LIGHT_GRAY_STAINED_GLASS_PANE,
                    ChatColor.YELLOW + "O trong " + (i + 1) + " - Dat item vao day") : data.items[i].clone();
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                List<String> lore = new ArrayList<>();
                lore.add(ChatColor.GRAY + "Gia ban: " + ChatColor.GREEN + String.format(Locale.US, "%.2f", data.prices[i]));
                lore.add(ChatColor.YELLOW + "Click khi tay khong cam item: doi gia qua chat");
                lore.add(ChatColor.RED + "Shift + chuot phai: xoa san pham");
                meta.setLore(lore);
                item.setItemMeta(meta);
            }
            inv.setItem(PRODUCT_SLOTS[i], item);
        }
        inv.setItem(SAVE_SLOT, named(Material.LIME_CONCRETE, ChatColor.GREEN + "LUU KE HANG"));
        inv.setItem(CLOSE_SLOT, named(Material.BARRIER, ChatColor.RED + "DONG"));
    }

    private ItemStack named(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) { meta.setDisplayName(name); item.setItemMeta(meta); }
        return item;
    }

    @EventHandler
    public void onEditorClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof ShelfHolder holder)) return;
        if (!isAdmin(player)) { event.setCancelled(true); player.closeInventory(); return; }

        int raw = event.getRawSlot();
        if (raw >= event.getView().getTopInventory().getSize()) {
            // Allow shift-clicking an item from the player's inventory into the first empty shelf slot.
            if (event.isShiftClick() && event.getCurrentItem() != null && !event.getCurrentItem().getType().isAir()) {
                event.setCancelled(true);
                ShelfData data = openEditors.get(player.getUniqueId().toString());
                if (data != null) {
                    int idx = firstEmpty(data);
                    if (idx >= 0) {
                        data.items[idx] = event.getCurrentItem().clone();
                        data.prices[idx] = 0.0;
                        event.setCurrentItem(null);
                        writeShelf(data);
                        render(event.getView().getTopInventory(), data);
                    } else player.sendMessage(ChatColor.RED + "Ke nay da du 3 san pham.");
                }
            }
            return;
        }
        event.setCancelled(true);
        ShelfData data = openEditors.get(player.getUniqueId().toString());
        if (data == null) return;

        if (raw == SAVE_SLOT) {
            // Any item physically placed in the three GUI slots is copied into the saved data.
            Inventory top = event.getView().getTopInventory();
            for (int i = 0; i < 3; i++) {
                ItemStack current = top.getItem(PRODUCT_SLOTS[i]);
                if (current != null && !current.getType().isAir()
                        && current.getType() != Material.LIGHT_GRAY_STAINED_GLASS_PANE) {
                    ItemStack copy = current.clone();
                    ItemMeta m = copy.getItemMeta();
                    if (m != null) m.setLore(null);
                    copy.setItemMeta(m);
                    data.items[i] = copy;
                }
            }
            writeShelf(data);
            player.sendMessage(ChatColor.GREEN + "Da luu ke hang. Gia 0$ nghia la chua cau hinh gia.");
            player.closeInventory();
            return;
        }
        if (raw == CLOSE_SLOT) { player.closeInventory(); return; }

        int idx = indexOfProductSlot(raw);
        if (idx < 0) return;
        ItemStack cursor = event.getCursor();
        if (event.isShiftClick() && event.isRightClick()) {
            data.items[idx] = null;
            data.prices[idx] = 0.0;
            writeShelf(data);
            render(event.getView().getTopInventory(), data);
            return;
        }
        if (cursor != null && !cursor.getType().isAir()) {
            ItemStack selected = cursor.clone();
            ItemMeta meta = selected.getItemMeta();
            if (meta != null) meta.setLore(null);
            selected.setItemMeta(meta);
            data.items[idx] = selected;
            data.prices[idx] = data.prices[idx] < 0 ? 0 : data.prices[idx];
            event.setCursor(null);
            writeShelf(data);
            render(event.getView().getTopInventory(), data);
            return;
        }
        if (data.items[idx] != null) {
            pendingPriceSlot.put(player.getUniqueId(), new PendingPrice(data.key, idx));
            player.closeInventory();
            player.sendMessage(ChatColor.YELLOW + "Nhap gia cho " + data.items[idx].getType().name() + " trong chat (so > 0). Nhap 'huy' de bo qua.");
        }
    }

    private int firstEmpty(ShelfData data) {
        for (int i = 0; i < 3; i++) if (data.items[i] == null) return i;
        return -1;
    }

    private int indexOfProductSlot(int raw) {
        for (int i = 0; i < PRODUCT_SLOTS.length; i++) if (PRODUCT_SLOTS[i] == raw) return i;
        return -1;
    }

    @EventHandler
    public void onPriceChat(org.bukkit.event.player.AsyncPlayerChatEvent event) {
        PendingPrice pending = pendingPriceSlot.get(event.getPlayer().getUniqueId());
        if (pending == null) return;
        event.setCancelled(true);
        String message = event.getMessage().trim();
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> {
            pendingPriceSlot.remove(player.getUniqueId());
            if (message.equalsIgnoreCase("huy")) {
                player.sendMessage(ChatColor.GRAY + "Da huy doi gia.");
                return;
            }
            double price;
            try { price = Double.parseDouble(message.replace(',', '.')); }
            catch (NumberFormatException ex) { player.sendMessage(ChatColor.RED + "Gia khong hop le. Hay mo lai ke va thu lai."); return; }
            if (!Double.isFinite(price) || price <= 0) { player.sendMessage(ChatColor.RED + "Gia phai lon hon 0."); return; }
            ShelfData data = readShelf(pending.shelfKey);
            if (data.items[pending.slot] == null) {
                player.sendMessage(ChatColor.RED + "San pham khong con tren ke.");
                return;
            }
            data.prices[pending.slot] = price;
            writeShelf(data);
            player.sendMessage(ChatColor.GREEN + "Da cap nhat gia: " + price + "$.");
            String[] parts = pending.shelfKey.split(",", 4);
            if (parts.length == 4) {
                org.bukkit.World world = Bukkit.getWorld(parts[0]);
                if (world != null) {
                    try {
                        Block block = world.getBlockAt(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3]));
                        if (isShelf(block.getType())) openEditor(player, block);
                    } catch (NumberFormatException ignored) { }
                }
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    public void onShelfBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (!isShelf(block.getType())) return;
        String shelfKey = key(block);
        String base = "shelves." + shelfKey;
        shelves.set(base, null);
        saveShelves();
        for (Entity entity : block.getWorld().getNearbyEntities(block.getLocation().add(0.5, 0.5, 0.5), 1.5, 1.5, 1.5)) {
            if (entity.getPersistentDataContainer().has(displayMarkerKey, PersistentDataType.BYTE)
                    && shelfKey.equals(entity.getPersistentDataContainer().get(displayShelfKey, PersistentDataType.STRING))) entity.remove();
        }
    }

    @EventHandler
    public void onEditorClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof ShelfHolder)) return;
        // Product edits are persisted immediately; SAVE is an explicit confirmation.
        openEditors.remove(event.getPlayer().getUniqueId().toString());
    }

    private static final class PendingPrice {
        final String shelfKey;
        final int slot;
        PendingPrice(String shelfKey, int slot) { this.shelfKey = shelfKey; this.slot = slot; }
    }

    private static final class ShelfData {
        final String key;
        final ItemStack[] items = new ItemStack[3];
        final double[] prices = new double[3];
        ShelfData(String key) { this.key = key; }
    }

    private static final class ShelfHolder implements InventoryHolder {
        final String key;
        Inventory inventory;
        ShelfHolder(String key) { this.key = key; }
        @Override public Inventory getInventory() { return inventory; }
    }
}
